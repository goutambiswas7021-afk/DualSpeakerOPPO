package com.example.dualspeaker

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import android.graphics.Typeface

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var list: LinearLayout
    private val selected = mutableSetOf<Int>()
    private val devices = mutableListOf<AudioDeviceInfo>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
        }
        val title = TextView(this).apply {
            text = "Dual Speaker Test"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
        }
        info = TextView(this).apply {
            textSize = 16f
            setPadding(0, 16, 0, 16)
        }
        val refresh = Button(this).apply {
            text = "Refresh audio outputs"
            setOnClickListener { showOutputs() }
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val note = TextView(this).apply {
            textSize = 14f
            setPadding(0, 18, 0, 0)
            text = "Important: Android usually lets normal apps play through only one Bluetooth A2DP output at a time. This test app cannot force OPPO's system to send all phone audio to two speakers. TWS pairing between the Philips speakers is the reliable wireless method."
        }
        root.addView(title); root.addView(info); root.addView(refresh); root.addView(list); root.addView(note)
        setContentView(ScrollView(this).apply { addView(root) })
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 7)
        } else showOutputs()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        showOutputs()
    }

    private fun showOutputs() {
        list.removeAllViews()
        devices.clear()
        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        val outputs = audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        for (d in outputs) {
            if (d.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                d.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                (Build.VERSION.SDK_INT >= 31 && d.type == AudioDeviceInfo.TYPE_BLE_HEADSET)) {
                devices.add(d)
            }
        }
        info.text = if (devices.isEmpty()) {
            "No Bluetooth audio outputs currently visible. Connect the speaker(s) in Android Bluetooth settings, then refresh."
        } else {
            "Bluetooth audio outputs visible to Android: ${devices.size}. Selectable outputs are shown below; this is a diagnostic test, not a guarantee of simultaneous playback."
        }
        devices.forEachIndexed { index, d ->
            val label = try { d.productName.toString() } catch (_: Exception) { "Bluetooth audio device ${index + 1}" }
            val cb = CheckBox(this).apply {
                text = "$label  (ID ${d.id})"
                textSize = 16f
                setOnCheckedChangeListener { _, checked ->
                    if (checked) selected.add(d.id) else selected.remove(d.id)
                    info.text = "Selected: ${selected.size}. This app can identify outputs, but Android/OPPO decides which Bluetooth speaker actually receives audio."
                }
            }
            list.addView(cb)
        }
        val test = Button(this).apply {
            text = "Check dual-output support"
            setOnClickListener {
                val msg = if (selected.size >= 2)
                    "Two outputs selected. Android exposes both devices, but public Android APIs do not guarantee two simultaneous Bluetooth A2DP streams. This app cannot enable Samsung Dual Audio if OPPO firmware does not support it."
                else "Select two Bluetooth audio outputs first. If only one appears, connect both in Bluetooth settings or use Philips TWS."
                AlertDialogBuilder.show(this@MainActivity, msg)
            }
        }
        list.addView(test)
    }
}

private object AlertDialogBuilder {
    fun show(activity: Activity, message: String) {
        android.app.AlertDialog.Builder(activity)
            .setTitle("Dual Speaker Test")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }
}
