plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.dualspeaker"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.dualspeaker"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}
